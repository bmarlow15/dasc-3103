import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;


public static class TokenizerMapper
  extends Mapper<Object, Text, Text, IntWritable> {

    public void map(Object key, Text value, Context context)
      throws IOException, InterruptedException {
        Map<String, Integer> map = new HashMap<String, Integer>();
        StringTokenizer itr = new StringTokenizer(value.toString());

        while (itr.hasMoreTokens()) {
            String token = itr.nextToken();
            if(map.containsKey(token)) {
                int total = map.get(token) + 1;
                map.put(token, total);
            } else {
                map.put(token, 1);
            } //end of if-else
        } // end of while

        Iterator<Map.Entry<String, Integer>> it = map.entrySet().iterator();
        while(it.hasNext()) {
            Map.Entry<String, Integer> entry = it.next();
            String sKey = entry.getKey();
            int total = entry.getValue().intValue();
            context.write(new Text(sKey), new IntWritable(total));
        } // end of while

    } // end of map method
} // end of mapper class